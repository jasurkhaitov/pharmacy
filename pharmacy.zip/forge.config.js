module.exports = {
  packagerConfig: {
    icon: './src/renderer/src/assets/Logo.webp'
  }
};
